"""Base de datos SQLite: tablas y operaciones básicas."""

import sqlite3

ARCHIVO = "repartos.db"


def conectar():
    conexion = sqlite3.connect(ARCHIVO)
    conexion.row_factory = sqlite3.Row
    conexion.execute("PRAGMA foreign_keys = ON")
    return conexion


def iniciar_db():
    conexion = conectar()
    cursor = conexion.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            ubicacion TEXT NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS riders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            ubicacion TEXT NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS restaurantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE,
            ubicacion TEXT NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS platos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            restaurante_id INTEGER NOT NULL,
            categoria TEXT NOT NULL,
            precio REAL NOT NULL CHECK (precio > 0),
            FOREIGN KEY (restaurante_id) REFERENCES restaurantes(id)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS caminos (
            origen TEXT NOT NULL,
            destino TEXT NOT NULL,
            distancia REAL NOT NULL CHECK (distancia > 0),
            PRIMARY KEY (origen, destino)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            rider_id INTEGER NOT NULL,
            fecha TEXT NOT NULL,
            hora_inicio INTEGER NOT NULL,
            hora_fin INTEGER NOT NULL,
            ruta TEXT NOT NULL,
            distancia REAL NOT NULL,
            total REAL NOT NULL,
            estado TEXT NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
            FOREIGN KEY (rider_id) REFERENCES riders(id)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS pedido_platos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL,
            plato_id INTEGER NOT NULL,
            cantidad INTEGER NOT NULL CHECK (cantidad > 0),
            precio_unitario REAL NOT NULL,
            FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
            FOREIGN KEY (plato_id) REFERENCES platos(id)
        )
    """)

    # Mapa de ejemplo. Se guarda solo la primera vez.
    if cursor.execute("SELECT COUNT(*) FROM caminos").fetchone()[0] == 0:
        tramos = [
            ("Centro", "Norte", 4),
            ("Centro", "Sur", 5),
            ("Centro", "Este", 3),
            ("Centro", "Oeste", 6),
            ("Norte", "Parque", 2),
            ("Este", "Parque", 4),
            ("Sur", "Universidad", 3),
            ("Oeste", "Universidad", 5),
            ("Parque", "Universidad", 6),
            ("Este", "Plaza", 2),
            ("Plaza", "Sur", 4)
        ]
        cursor.executemany(
            "INSERT INTO caminos (origen, destino, distancia) VALUES (?, ?, ?)",
            tramos
        )

    conexion.commit()
    conexion.close()


def guardar_usuario(nombre, ubicacion):
    conexion = conectar()
    conexion.execute(
        "INSERT INTO usuarios (nombre, ubicacion) VALUES (?, ?)",
        (nombre, ubicacion)
    )
    conexion.commit()
    conexion.close()


def guardar_rider(nombre, ubicacion):
    conexion = conectar()
    conexion.execute(
        "INSERT INTO riders (nombre, ubicacion) VALUES (?, ?)",
        (nombre, ubicacion)
    )
    conexion.commit()
    conexion.close()


def guardar_restaurante(nombre, ubicacion):
    conexion = conectar()
    conexion.execute(
        "INSERT INTO restaurantes (nombre, ubicacion) VALUES (?, ?)",
        (nombre, ubicacion)
    )
    conexion.commit()
    conexion.close()


def guardar_plato(nombre, restaurante_id, categoria, precio):
    conexion = conectar()
    conexion.execute("""
        INSERT INTO platos (nombre, restaurante_id, categoria, precio)
        VALUES (?, ?, ?, ?)
    """, (nombre, restaurante_id, categoria, precio))
    conexion.commit()
    conexion.close()


def guardar_camino(origen, destino, distancia):
    # Ordenamos los nombres porque los caminos sirven en ambos sentidos.
    if origen == destino:
        raise ValueError("El origen y el destino deben ser distintos.")
    if distancia <= 0:
        raise ValueError("La distancia debe ser mayor que cero.")
    conexion = conectar()
    conexion.execute("""
        INSERT OR REPLACE INTO caminos (origen, destino, distancia)
        VALUES (?, ?, ?)
    """, (min(origen, destino), max(origen, destino), distancia))
    conexion.commit()
    conexion.close()


def consultar(sql, datos=()):
    conexion = conectar()
    filas = conexion.execute(sql, datos).fetchall()
    conexion.close()
    return filas
