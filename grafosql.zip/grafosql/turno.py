"""Asignación voraz de riders sin solapar repartos."""

import rutas


def rider_libre(conexion, rider_id, fecha, inicio, fin):
    # Un rider está ocupado si sus intervalos se cruzan.
    ocupado = conexion.execute("""
        SELECT COUNT(*) FROM pedidos
        WHERE rider_id = ? AND fecha = ?
          AND hora_inicio < ? AND hora_fin > ?
    """, (rider_id, fecha, fin, inicio)).fetchone()[0]
    return ocupado == 0


def asignar_rider(conexion, grafo, restaurantes, destino, fecha, inicio, fin):
    """Busca al rider libre más cercano al primer restaurante.

    Después calcula la ruta por todos los restaurantes y el cliente.
    No escribe en la base de datos: pedidos.py guarda todo junto.
    """
    riders = conexion.execute("SELECT * FROM riders ORDER BY id").fetchall()
    libres = []

    for rider in riders:
        if rider_libre(conexion, rider["id"], fecha, inicio, fin):
            libres.append(rider)

    if not libres:
        raise ValueError("No hay riders libres en ese horario.")

    rider = rutas.rider_mas_cercano(grafo, libres, restaurantes[0])
    if rider is None:
        raise ValueError("Ningún rider libre puede llegar al restaurante.")

    lugares = restaurantes + [destino]
    ruta_completa = [rider["ubicacion"]]
    distancia_total = 0
    anterior = rider["ubicacion"]

    for lugar in lugares:
        tramo, distancia = rutas.dijkstra(grafo, anterior, lugar)
        ruta_completa.extend(tramo[1:])
        distancia_total += distancia
        anterior = lugar

    return rider, ruta_completa, distancia_total
