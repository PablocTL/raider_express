"""Menú principal: aquí se introducen todos los datos."""

from datetime import datetime
import db
import pedidos
import rutas


def leer_texto(mensaje):
    while True:
        valor = input(mensaje).strip()
        if valor:
            return valor
        print("No puede estar vacío.")


def leer_entero(mensaje, minimo=0):
    while True:
        try:
            numero = int(input(mensaje))
            if numero >= minimo:
                return numero
        except ValueError:
            pass
        print("Introduce un número entero válido.")


def leer_decimal(mensaje):
    while True:
        try:
            numero = float(input(mensaje).replace(",", "."))
            if numero > 0:
                return numero        
            return numero
        except ValueError:
            pass
        print("Introduce un número mayor que cero.")


def elegir_lugar():
    lugares = sorted(rutas.cargar_grafo().nodes())
    print("\nUbicaciones del mapa:")
    for numero, lugar in enumerate(lugares, 1):
        print(numero, "-", lugar)
    while True:
        numero = leer_entero("Número de ubicación: ", 1)
        if numero <= len(lugares):
            return lugares[numero - 1]
        print("Ubicación no válida.")


def ver_usuarios():
    usuarios = db.consultar("SELECT * FROM usuarios ORDER BY id")
    print("\nUSUARIOS")
    for u in usuarios:
        print(u["id"], "-", u["nombre"], "-", u["ubicacion"])
    return usuarios


def ver_riders():
    riders = db.consultar("SELECT * FROM riders ORDER BY id")
    print("\nRIDERS")
    for r in riders:
        print(r["id"], "-", r["nombre"], "-", r["ubicacion"])
    return riders


def ver_restaurantes():
    restaurantes = db.consultar("SELECT * FROM restaurantes ORDER BY id")
    print("\nRESTAURANTES")
    for r in restaurantes:
        print(r["id"], "-", r["nombre"], "-", r["ubicacion"])
    return restaurantes


def ver_platos():
    platos = db.consultar("""
        SELECT p.id, p.nombre, r.nombre AS restaurante, p.categoria, p.precio
        FROM platos p JOIN restaurantes r ON r.id = p.restaurante_id
        ORDER BY p.id
    """)
    print("\nPLATOS")
    for p in platos:
        print(f'{p["id"]} - {p["nombre"]} | {p["restaurante"]} | '
              f'{p["categoria"]} | {p["precio"]:.2f} €')
    return platos


def registrar_usuario():
    nombre = leer_texto("Nombre del usuario: ")
    ubicacion = elegir_lugar()
    db.guardar_usuario(nombre, ubicacion)
    print("Usuario guardado en SQLite.")


def registrar_rider():
    nombre = leer_texto("Nombre del rider: ")
    ubicacion = elegir_lugar()
    db.guardar_rider(nombre, ubicacion)
    print("Rider guardado en SQLite.")


def registrar_restaurante():
    nombre = leer_texto("Nombre del restaurante: ")
    ubicacion = elegir_lugar()
    db.guardar_restaurante(nombre, ubicacion)
    print("Restaurante guardado en SQLite.")

def registrar_plato():
    if not ver_restaurantes():
        print("Antes registra un restaurante.")
        return
    nombre = leer_texto("Nombre del plato: ")
    restaurante_id = leer_entero("ID del restaurante: ", 1)
    categoria = leer_texto("Categoría del plato: ")
    precio = leer_decimal("Precio (€): ")
    db.guardar_plato(nombre, restaurante_id, categoria, precio)
    print("Plato guardado en SQLite.")


def leer_fecha():
    while True:
        fecha = input("Fecha del reparto (AAAA-MM-DD): ").strip()
        try:
            datetime.strptime(fecha, "%Y-%m-%d")
            return fecha
        except ValueError:
            print("Fecha incorrecta. Ejemplo: 2026-10-22")


def leer_hora():
    while True:
        texto = input("Hora de inicio (HH:MM): ").strip()
        try:
            hora = datetime.strptime(texto, "%H:%M")
            return hora.hour * 60 + hora.minute
        except ValueError:
            print("Hora incorrecta. Ejemplo: 14:30")


def formato_hora(minutos):
    return f"{minutos // 60:02d}:{minutos % 60:02d}"


def nuevo_pedido():
    if not ver_usuarios():
        print("Primero registra un usuario.")
        return
    if not ver_riders():
        print("Primero registra un rider.")
        return
    if not ver_platos():
        print("Primero registra platos.")
        return

    usuario_id = leer_entero("ID del usuario: ", 1)
    seleccion = []
    print("Elige platos. Escribe 0 para terminar.")
    while True:
        plato_id = leer_entero("ID del plato (0 para terminar): ")
        if plato_id == 0:
            break
        cantidad = leer_entero("Cantidad: ", 1)
        seleccion.append((plato_id, cantidad))

    if not seleccion:
        print("Pedido vacío: no se ha guardado.")
        return

    fecha = leer_fecha()
    inicio = leer_hora()
    duracion = leer_entero("Duración prevista en minutos: ", 1)
    respuesta = leer_texto("¿Tarjeta aprobada? (s/n): ").lower()
    aprobada = respuesta == "s"

    pedido_id, rider, ruta, total = pedidos.crear_pedido(
        usuario_id, seleccion, fecha, inicio, duracion, aprobada
    )
    print("\nPEDIDO CONFIRMADO. ID:", pedido_id)
    print("Rider asignado:", rider)
    print("Ruta con Dijkstra:", ruta)
    print("Total:", f"{total:.2f} €")


def ver_pedidos():
    todos = pedidos.ver_pedidos()
    print("\nPEDIDOS CONFIRMADOS")
    if not todos:
        print("Todavía no hay pedidos.")
    for p in todos:
        print("\nPedido:", p["id"], "| Usuario:", p["usuario"])
        print("Rider:", p["rider"], "|", p["fecha"],
              formato_hora(p["hora_inicio"]), "-", formato_hora(p["hora_fin"]))
        print("Ruta:", p["ruta"])
        print("Distancia:", p["distancia"], "| Total:", f'{p["total"]:.2f} €')
        for detalle in pedidos.ver_platos_pedido(p["id"]):
            print("   -", detalle["nombre"], "x", detalle["cantidad"],
                  "(", detalle["restaurante"], ")")


def ver_turnos():
    print("\nTURNOS DE RIDERS (sin solapamientos)")
    todos = db.consultar("""
        SELECT p.fecha, p.hora_inicio, p.hora_fin, p.id, r.nombre AS rider
        FROM pedidos p JOIN riders r ON r.id = p.rider_id
        ORDER BY p.fecha, r.nombre, p.hora_inicio
    """)
    if not todos:
        print("No hay turnos asignados.")
    for t in todos:
        print(t["fecha"], t["rider"],
              formato_hora(t["hora_inicio"]), "-",
              formato_hora(t["hora_fin"]), "Pedido", t["id"])


def ver_mapa():
    print("\nMAPA (tramos y distancias)")
    for t in db.consultar("SELECT * FROM caminos ORDER BY origen, destino"):
        print(t["origen"], "<->", t["destino"], "|", t["distancia"], "km")


def anadir_camino():
    print("Añadir una conexión entre dos ubicaciones.")
    origen = leer_texto("Origen (nombre): ")
    destino = leer_texto("Destino (nombre): ")
    distancia = leer_decimal("Distancia en km: ")
    db.guardar_camino(origen, destino, distancia)
    print("Camino guardado. Dijkstra lo tendrá en cuenta.")


def menu():
    opciones = {
        "1": registrar_usuario,
        "2": registrar_rider,
        "3": registrar_restaurante,
        "4": registrar_plato,
        "5": nuevo_pedido,
        "6": ver_pedidos,
        "7": ver_turnos,
        "8": ver_platos,
        "9": ver_mapa,
        "10": anadir_camino,
    }

    while True:
        print("\n======= APP DE REPARTOS =======")
        print("1. Registrar usuario")
        print("2. Registrar rider")
        print("3. Registrar restaurante")
        print("4. Registrar plato")
        print("5. Crear pedido (transacción)")
        print("6. Ver pedidos")
        print("7. Ver turnos de riders")
        print("8. Ver platos")
        print("9. Ver mapa")
        print("10. Añadir camino al mapa")
        print("0. Salir")
        opcion = input("Elige una opción: ").strip()

        if opcion == "0":
            print("¡Hasta luego!")
            break
        if opcion in opciones:
            try:
                opciones[opcion]()
            except Exception as error:
                print("ERROR:", error)
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    db.iniciar_db()
    menu()

    