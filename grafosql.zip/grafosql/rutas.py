"""Caminos mínimos con el algoritmo de Dijkstra (NetworkX)."""

import networkx as nx
import db


def cargar_grafo(conexion=None):
    # El grafo se crea a partir de los caminos de SQLite.
    if conexion is None:
        tramos = db.consultar("SELECT * FROM caminos")
    else:
        tramos = conexion.execute("SELECT * FROM caminos").fetchall()

    grafo = nx.Graph()
    for tramo in tramos:
        grafo.add_edge(
            tramo["origen"], tramo["destino"],
            weight=tramo["distancia"]
        )
    return grafo


def dijkstra(grafo, origen, destino):
    """Devuelve (camino, distancia) o lanza ValueError si no hay ruta."""
    if origen not in grafo or destino not in grafo:
        raise ValueError("Una ubicación no existe en el mapa.")
    try:
        distancia, camino = nx.single_source_dijkstra(
            grafo, origen, destino, weight="weight"
        )
        return camino, distancia
    except nx.NetworkXNoPath:
        raise ValueError("No existe un camino entre esas ubicaciones.")


def camino(grafo, origen, destino):
    recorrido, distancia = dijkstra(grafo, origen, destino)
    return " -> ".join(recorrido), distancia


def rider_mas_cercano(grafo, riders, restaurante):
    """Algoritmo voraz: entre los riders libres, el más cercano."""
    mejor_rider = None
    menor_distancia = float("inf")

    for rider in riders:
        try:
            recorrido, distancia = dijkstra(
                grafo, rider["ubicacion"], restaurante
            )
        except ValueError:
            continue
        if distancia < menor_distancia:
            menor_distancia = distancia
            mejor_rider = rider

    return mejor_rider