"""Crear pedidos como transacciones: COMMIT o ROLLBACK."""

import db
import rutas
import turno


def crear_pedido(usuario_id, seleccion, fecha, inicio, duracion, tarjeta_aprobada):
    """seleccion: lista [(id_plato, cantidad), ...].

    Si la tarjeta es rechazada, se hace ROLLBACK: no queda pedido.
    """
    if not seleccion:
        raise ValueError("Debes elegir al menos un plato.")
    if inicio < 0 or duracion <= 0 or inicio + duracion > 1440:
        raise ValueError("El horario debe estar dentro del mismo día.")

    conexion = db.conectar()
    try:
        conexion.execute("BEGIN IMMEDIATE")

        usuario = conexion.execute(
            "SELECT * FROM usuarios WHERE id = ?", (usuario_id,)
        ).fetchone()
        if usuario is None:
            raise ValueError("El usuario no existe.")

        total = 0
        detalles = []
        restaurantes = []
        for plato_id, cantidad in seleccion:
            if cantidad <= 0:
                raise ValueError("La cantidad debe ser mayor que cero.")

            plato = conexion.execute("""
                SELECT p.*, r.ubicacion AS lugar_restaurante
                FROM platos p
                JOIN restaurantes r ON r.id = p.restaurante_id
                WHERE p.id = ?
            """, (plato_id,)).fetchone()
            if plato is None:
                raise ValueError("No existe el plato con ID " + str(plato_id))

            total += plato["precio"] * cantidad
            detalles.append((plato_id, cantidad, plato["precio"]))
            lugar = plato["lugar_restaurante"]
            if lugar not in restaurantes:
                restaurantes.append(lugar)

        grafo = rutas.cargar_grafo(conexion)
        rider, recorrido, distancia = turno.asignar_rider(
            conexion, grafo, restaurantes, usuario["ubicacion"],
            fecha, inicio, inicio + duracion
        )

        cursor = conexion.execute("""
            INSERT INTO pedidos
                (usuario_id, rider_id, fecha, hora_inicio, hora_fin,
                 ruta, distancia, total, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            usuario_id, rider["id"], fecha, inicio, inicio + duracion,
            " -> ".join(recorrido), distancia, round(total, 2), "confirmado"
        ))
        pedido_id = cursor.lastrowid

        for plato_id, cantidad, precio in detalles:
            conexion.execute("""
                INSERT INTO pedido_platos
                    (pedido_id, plato_id, cantidad, precio_unitario)
                VALUES (?, ?, ?, ?)
            """, (pedido_id, plato_id, cantidad, precio))

        # Rechazo simulado: ya hemos insertado, pero aún NO confirmado.
        if not tarjeta_aprobada:
            raise ValueError("Tarjeta rechazada. ROLLBACK: pedido cancelado.")

        conexion.commit()  # Todo el pedido se guarda a la vez.
        return pedido_id, rider["nombre"], " -> ".join(recorrido), round(total, 2)

    except Exception:
        conexion.rollback()  # Deshace el pedido y todos sus detalles.
        raise
    finally:
        conexion.close()


def ver_pedidos():
    return db.consultar("""
        SELECT p.*, u.nombre AS usuario, r.nombre AS rider
        FROM pedidos p
        JOIN usuarios u ON u.id = p.usuario_id
        JOIN riders r ON r.id = p.rider_id
        ORDER BY p.fecha, p.hora_inicio, p.id
    """)


def ver_platos_pedido(pedido_id):
    return db.consultar("""
        SELECT pl.nombre, d.cantidad, d.precio_unitario,
               re.nombre AS restaurante
        FROM pedido_platos d
        JOIN platos pl ON pl.id = d.plato_id
        JOIN restaurantes re ON re.id = pl.restaurante_id
        WHERE d.pedido_id = ?
    """, (pedido_id,))
