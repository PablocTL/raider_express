"""app.py - El menú: lo único que habla con el usuario."""
import sqlite3

import db
import pedidos
import rutas
import turno


# ---------------------------------------------------------------- utilidades de entrada/salida
def pedir_int(msg, minimo, maximo):
    while True:
        txt = input(msg).strip()
        if txt.lstrip("-").isdigit() and minimo <= int(txt) <= maximo:
            return int(txt)
        print(f"  Introduce un número entre {minimo} y {maximo}.")


def pedir_float(msg):
    while True:
        try:
            v = float(input(msg).replace(",", "."))
            if v > 0:
                return v
        except ValueError:
            pass
        print("  Introduce un importe positivo.")


def elegir(titulo, opciones, fmt=str):
    print(f"\n{titulo}")
    for i, o in enumerate(opciones, 1):
        print(f"  {i:>2}. {fmt(o)}")
    return opciones[pedir_int("Elige una opción: ", 1, len(opciones)) - 1]


def tabla(filas, columnas):
    """columnas = [(clave, cabecera)]"""
    if not filas:
        print("  (sin datos)")
        return
    ancho = [max(len(c[1]), *(len(str(f[c[0]])) for f in filas)) for c in columnas]
    print("  " + " | ".join(c[1].ljust(w) for c, w in zip(columnas, ancho)))
    print("  " + "-+-".join("-" * w for w in ancho))
    for f in filas:
        print("  " + " | ".join(str(f[c[0]]).ljust(w) for c, w in zip(columnas, ancho)))


def mostrar_ruta(ruta, estado, vehiculo=None):
    pasos = rutas.describir_ruta(ruta, estado["grafo"], estado["calles"])
    for p in pasos:
        print("    " + p)
    metros = sum(estado["grafo"][a][b] for a, b in zip(ruta, ruta[1:]))
    extra = f" (~{rutas.minutos(metros, vehiculo)} min en {vehiculo.lower()})" if vehiculo else ""
    print(f"    Total: {metros} m{extra}")
    return metros


# ---------------------------------------------------------------- opciones del menú
def listar_restaurantes(_):
    cocina = elegir("Tipo de cocina:", ["(todas)"] + db.COCINAS)
    filas = db.listar_restaurantes(None if cocina == "(todas)" else cocina)
    tabla(filas, [("restaurante", "Restaurante"), ("cocina", "Cocina"), ("nodo", "Zona"), ("platos", "Platos")])


def elegir_restaurante():
    cocina = elegir("Tipo de cocina:", db.COCINAS)
    return elegir("Restaurante:", db.listar_restaurantes(cocina),
                  lambda r: f"{r['restaurante']}  [{r['nodo']}]")["restaurante"]


def ver_carta(_):
    nombre = elegir_restaurante()
    print(f"\nCarta de {nombre}")
    tabla(db.platos_de_restaurante(nombre),
          [("id", "ID"), ("nombre", "Plato"), ("categoria", "Categoría"), ("precio", "Precio €")])


def hacer_pedido(estado, forzar_rechazo=False):
    usuario = elegir("¿Quién pide?", db.listar_usuarios(),
                     lambda u: f"{u['nombre']} ({u['barrio']}) - saldo {u['saldo']:.2f} €")
    restaurante = elegir_restaurante()
    carta = db.platos_de_restaurante(restaurante)
    print(f"\nCarta de {restaurante}")
    for i, p in enumerate(carta, 1):
        print(f"  {i:>2}. {p['nombre']:<30} {p['categoria']:<10} {p['precio']:>6.2f} €")
    items = {}
    while True:
        n = pedir_int("Nº de plato (0 para terminar): ", 0, len(carta))
        if n == 0:
            break
        items[carta[n - 1]["id"]] = pedir_int("  Cantidad: ", 1, 20)
    if not items:
        print("Pedido cancelado.")
        return

    riders = {r["id"]: r for r in db.listar_riders()}
    nodo_rest = db.NODO_DE[restaurante]
    rid, metros, ruta_rider = rutas.rider_mas_cercano(estado["grafo"], nodo_rest, estado["posiciones"])
    try:
        res = pedidos.crear_pedido(usuario["id"], items, rid, forzar_rechazo)
    except pedidos.PedidoError as e:
        print(f"\n✗ {e}\n  Nada se ha guardado (rollback).")
        return
    rider = riders[rid]
    print(f"\n✓ Pedido #{res['pedido_id']} creado. Total cobrado: {res['total']:.2f} €")
    print(f"  Rider asignado: {rider['nombre']} ({rider['vehiculo']}), a {metros} m del restaurante.")
    print(f"\n  Ruta rider -> {restaurante}:")
    mostrar_ruta(ruta_rider, estado, rider["vehiculo"])
    print(f"\n  Ruta {restaurante} -> casa de {usuario['nombre']} ({usuario['barrio']}):")
    ruta_cliente, _ = rutas.ruta_mas_corta(estado["grafo"], nodo_rest, usuario["barrio"])
    mostrar_ruta(ruta_cliente, estado, rider["vehiculo"])
    estado["posiciones"][rid] = usuario["barrio"]  # el rider termina en casa del cliente


def demo_rechazo(estado):
    print("\nDEMO: pedido de 99 unidades de un plato con un usuario con poco saldo.")
    usuario = min(db.listar_usuarios(), key=lambda u: u["saldo"])
    plato = db.platos_de_restaurante("Burger Sol")[0]
    antes = db.contar_pedidos()
    print(f"  Usuario: {usuario['nombre']} (saldo {usuario['saldo']:.2f} €)  Plato: {plato['nombre']} x99")
    try:
        pedidos.crear_pedido(usuario["id"], {plato["id"]: 99}, 1)
    except pedidos.TarjetaRechazada as e:
        print(f"  ✗ {e}")
    print(f"  Pedidos antes: {antes} | después: {db.contar_pedidos()}  -> la transacción se deshizo.")


def consultar_ruta(estado):
    nodos = sorted(estado["grafo"])
    a = elegir("Origen:", nodos)
    b = elegir("Destino:", nodos)
    ruta, _ = rutas.ruta_mas_corta(estado["grafo"], a, b)
    print(f"\nRuta más corta {a} -> {b}:")
    mostrar_ruta(ruta, estado)


def informes(_):
    op = elegir("Informe:", ["Ventas por restaurante (top 10)", "Platos más vendidos (top 10)",
                             "Gasto por usuario", "Pedidos por rider"])
    if op.startswith("Ventas"):
        tabla(db.ventas_por_restaurante(), [("restaurante", "Restaurante"), ("pedidos", "Pedidos"), ("ingresos", "Ingresos €")])
    elif op.startswith("Platos"):
        tabla(db.platos_mas_vendidos(), [("nombre", "Plato"), ("restaurante", "Restaurante"), ("unidades", "Unidades")])
    elif op.startswith("Gasto"):
        tabla(db.gasto_por_usuario(), [("nombre", "Usuario"), ("barrio", "Barrio"), ("pedidos", "Pedidos"), ("gastado", "Gastado €")])
    else:
        tabla(db.pedidos_por_rider(), [("nombre", "Rider"), ("vehiculo", "Vehículo"), ("pedidos", "Pedidos")])


def turno_voraz(_):
    todos = db.listar_repartos()
    elegidos = turno.voraz(todos)
    print(f"\nHay {len(todos)} repartos posibles (se solapan entre sí). El voraz elige {len(elegidos)} sin solapar:")
    tabla(elegidos, [("id", "ID"), ("zona", "Zona"), ("inicio", "Inicio"), ("fin", "Fin")])
    h, m = divmod(turno.minutos_trabajados(elegidos), 60)
    print(f"  Tiempo total de reparto: {h} h {m} min")


def gestionar_usuarios(_):
    op = elegir("Usuarios:", ["Listar", "Alta", "Recargar saldo", "Baja"])
    if op == "Listar":
        tabla(db.listar_usuarios(), [("id", "ID"), ("nombre", "Nombre"), ("barrio", "Barrio"), ("saldo", "Saldo €")])
    elif op == "Alta":
        nombre = input("Nombre: ").strip()
        barrio = elegir("Barrio:", sorted(rutas.NODOS))
        uid = db.crear_usuario(nombre, barrio, 0.0)
        print(f"Usuario creado con id {uid}.")
    elif op == "Recargar saldo":
        u = elegir("Usuario:", db.listar_usuarios(), lambda u: f"{u['nombre']} ({u['saldo']:.2f} €)")
        db.recargar_saldo(u["id"], pedir_float("Importe a recargar: "))
        print("Saldo actualizado.")
    else:
        u = elegir("Usuario a borrar:", db.listar_usuarios(), lambda u: u["nombre"])
        try:
            db.borrar_usuario(u["id"])
            print("Usuario borrado.")
        except sqlite3.IntegrityError:
            print("No se puede borrar: el usuario tiene pedidos.")


MENU = [
    ("Ver restaurantes", listar_restaurantes),
    ("Ver carta de un restaurante", ver_carta),
    ("Hacer un pedido (rider más cercano + ruta)", hacer_pedido),
    ("Demo: tarjeta rechazada (rollback)", demo_rechazo),
    ("Ruta más corta entre dos zonas de Madrid", consultar_ruta),
    ("Informes", informes),
    ("Turno de repartos sin solapar (voraz)", turno_voraz),
    ("Gestión de usuarios", gestionar_usuarios),
]


def main():
    db.init_db()
    grafo, calles = rutas.cargar_grafo()
    estado = {"grafo": grafo, "calles": calles,
              "posiciones": rutas.posiciones_iniciales([r["id"] for r in db.listar_riders()])}
    while True:
        print("\n=== RiderExpress ===")
        for i, (texto, _) in enumerate(MENU, 1):
            print(f"  {i}. {texto}")
        print("  0. Salir")
        op = pedir_int("Opción: ", 0, len(MENU))
        if op == 0:
            print("¡Hasta pronto!")
            return
        MENU[op - 1][1](estado)


if __name__ == "__main__":
    main()
