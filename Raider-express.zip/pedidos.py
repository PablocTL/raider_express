"""pedidos.py - crear_pedido como transacción (tarjeta rechazada => rollback completo)."""
from datetime import datetime

import db


class PedidoError(Exception):
    pass


class TarjetaRechazada(PedidoError):
    pass


def crear_pedido(usuario_id, items, rider_id, forzar_rechazo=False):
    """items = {plato_id: cantidad}. Inserta pedido + líneas y cobra el total.
    Si el cobro falla se deshace TODO (no queda ni pedido ni líneas)."""
    if not items or any(c <= 0 for c in items.values()):
        raise PedidoError("El pedido está vacío o tiene cantidades no válidas.")
    conn = db.conectar()
    try:
        with conn:  # COMMIT si todo va bien, ROLLBACK si salta cualquier excepción
            marcas = ",".join("?" * len(items))
            platos = conn.execute(
                f"SELECT id, nombre, restaurante, precio FROM plato WHERE id IN ({marcas})",
                list(items)).fetchall()
            if len(platos) != len(items):
                raise PedidoError("Algún plato no existe.")
            restaurantes = {p["restaurante"] for p in platos}
            if len(restaurantes) > 1:
                raise PedidoError("Todos los platos deben ser del mismo restaurante.")
            usuario = conn.execute("SELECT saldo FROM usuario WHERE id = ?", (usuario_id,)).fetchone()
            if usuario is None:
                raise PedidoError("El usuario no existe.")
            total = round(sum(p["precio"] * items[p["id"]] for p in platos), 2)

            cur = conn.execute("INSERT INTO pedido (fecha, usuario_id, rider_id) VALUES (?, ?, ?)",
                               (datetime.now().isoformat(timespec="seconds"), usuario_id, rider_id))
            pedido_id = cur.lastrowid
            conn.executemany("INSERT INTO pedido_plato (pedido_id, plato_id, cantidad) VALUES (?, ?, ?)",
                             [(pedido_id, pid, cant) for pid, cant in items.items()])

            # Cobro: el último paso, para que el rollback tenga algo que deshacer
            if forzar_rechazo or usuario["saldo"] < total:
                raise TarjetaRechazada(
                    f"Tarjeta rechazada: el pedido cuesta {total:.2f} € y el saldo es {usuario['saldo']:.2f} €.")
            conn.execute("UPDATE usuario SET saldo = saldo - ? WHERE id = ?", (total, usuario_id))
        return {"pedido_id": pedido_id, "total": total, "restaurante": restaurantes.pop()}
    finally:
        conn.close()
