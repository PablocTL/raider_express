"""turno.py - El voraz de repartos sin solapar (selección de actividades)."""
import db


def _min(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def voraz(repartos):
    """Ordena por hora de fin y se queda con cada reparto que empieza cuando el último elegido ya terminó.
    Este criterio garantiza el mayor número posible de repartos sin solaparse."""
    elegidos, ultimo_fin = [], -1
    for r in sorted(repartos, key=lambda r: (_min(r["fin"]), _min(r["inicio"]))):
        if _min(r["inicio"]) >= ultimo_fin:
            elegidos.append(r)
            ultimo_fin = _min(r["fin"])
    return elegidos


def turno_optimo():
    return voraz(db.listar_repartos())


def minutos_trabajados(repartos):
    return sum(_min(r["fin"]) - _min(r["inicio"]) for r in repartos)
