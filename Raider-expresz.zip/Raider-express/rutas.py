"""rutas.py - Grafo de calles de Madrid: cargar_grafo, dijkstra, camino, rider_mas_cercano."""
import heapq
import random
from math import asin, cos, radians, sin, sqrt
from time import perf_counter

# Nodos = plazas, cruces y barrios de Madrid (lat, lon aproximadas)
NODOS = {
    "Sol": (40.4169, -3.7035), "Plaza Mayor": (40.4155, -3.7074),
    "Callao": (40.4203, -3.7060), "Red de San Luis": (40.4208, -3.7020),
    "Sevilla": (40.4180, -3.6990), "Banco de España": (40.4195, -3.6945),
    "Cibeles": (40.4193, -3.6931), "Puerta de Alcalá": (40.4200, -3.6888),
    "Colón": (40.4251, -3.6892), "Chueca": (40.4228, -3.6975),
    "Alonso Martínez": (40.4280, -3.6946), "Tribunal": (40.4263, -3.7010),
    "Bilbao": (40.4291, -3.7075), "Malasaña": (40.4252, -3.7048),
    "San Bernardo": (40.4285, -3.7040), "Plaza de España": (40.4237, -3.7122),
    "Santo Domingo": (40.4194, -3.7108), "Ópera": (40.4181, -3.7106),
    "Plaza de Oriente": (40.4180, -3.7140), "Príncipe Pío": (40.4210, -3.7200),
    "Moncloa": (40.4348, -3.7190), "Argüelles": (40.4306, -3.7142),
    "Segovia": (40.4135, -3.7140), "La Latina": (40.4120, -3.7090),
    "Tirso de Molina": (40.4122, -3.7055), "Antón Martín": (40.4122, -3.6990),
    "Lavapiés": (40.4085, -3.7011), "Embajadores": (40.4035, -3.7035),
    "Puerta de Toledo": (40.4070, -3.7110), "Atocha": (40.4065, -3.6895),
    "Legazpi": (40.3910, -3.6950), "Gregorio Marañón": (40.4344, -3.6900),
    "Nuevos Ministerios": (40.4458, -3.6926), "Plaza de Castilla": (40.4660, -3.6890),
    "Chamberí": (40.4340, -3.7040), "Velázquez": (40.4247, -3.6838),
    "Goya": (40.4250, -3.6775), "Ibiza": (40.4205, -3.6718),
    "Manuel Becerra": (40.4300, -3.6720),
}

# Calles que unen dos nodos (nombres y trazado aproximados)
CALLES = [
    ("Sol", "Plaza Mayor", "Calle Mayor"),
    ("Sol", "Callao", "Calle de Preciados"),
    ("Sol", "Sevilla", "Calle de Alcalá"),
    ("Sol", "Ópera", "Calle del Arenal"),
    ("Sol", "Antón Martín", "Calle de Atocha"),
    ("Plaza Mayor", "Ópera", "Calle Mayor"),
    ("Plaza Mayor", "La Latina", "Calle de Toledo"),
    ("Plaza Mayor", "Tirso de Molina", "Calle de Toledo"),
    ("Tirso de Molina", "La Latina", "Calle de Embajadores"),
    ("Tirso de Molina", "Antón Martín", "Calle de Atocha"),
    ("Tirso de Molina", "Lavapiés", "Calle del Ave María"),
    ("Antón Martín", "Lavapiés", "Calle de Santa Isabel"),
    ("Antón Martín", "Atocha", "Calle de Atocha"),
    ("Lavapiés", "Embajadores", "Calle de Embajadores"),
    ("Embajadores", "Atocha", "Calle de Santa María de la Cabeza"),
    ("Embajadores", "Puerta de Toledo", "Ronda de Toledo"),
    ("Embajadores", "Legazpi", "Paseo de las Delicias"),
    ("Atocha", "Legazpi", "Paseo de las Delicias"),
    ("La Latina", "Puerta de Toledo", "Calle de Toledo"),
    ("La Latina", "Segovia", "Calle de Segovia"),
    ("Segovia", "Plaza de Oriente", "Calle de Bailén"),
    ("Ópera", "Plaza de Oriente", "Calle de Arrieta"),
    ("Ópera", "Santo Domingo", "Calle de Santo Domingo"),
    ("Santo Domingo", "Callao", "Calle de Jacometrezo"),
    ("Santo Domingo", "Plaza de España", "Calle de la Bola"),
    ("Callao", "Plaza de España", "Gran Vía"),
    ("Callao", "Red de San Luis", "Gran Vía"),
    ("Red de San Luis", "Chueca", "Calle de Hortaleza"),
    ("Red de San Luis", "Tribunal", "Calle de Fuencarral"),
    ("Red de San Luis", "Sevilla", "Calle de la Montera"),
    ("Sevilla", "Banco de España", "Calle de Alcalá"),
    ("Banco de España", "Cibeles", "Calle de Alcalá"),
    ("Banco de España", "Chueca", "Calle del Barquillo"),
    ("Cibeles", "Puerta de Alcalá", "Calle de Alcalá"),
    ("Cibeles", "Colón", "Paseo de Recoletos"),
    ("Cibeles", "Atocha", "Paseo del Prado"),
    ("Chueca", "Alonso Martínez", "Calle de Fernando VI"),
    ("Colón", "Alonso Martínez", "Calle de Génova"),
    ("Colón", "Gregorio Marañón", "Paseo de la Castellana"),
    ("Colón", "Velázquez", "Calle de Jorge Juan"),
    ("Puerta de Alcalá", "Velázquez", "Calle de Velázquez"),
    ("Puerta de Alcalá", "Ibiza", "Calle de Alcalá"),
    ("Velázquez", "Goya", "Calle de Goya"),
    ("Goya", "Manuel Becerra", "Calle de Alcalá"),
    ("Goya", "Ibiza", "Calle de O'Donnell"),
    ("Alonso Martínez", "Bilbao", "Calle de Sagasta"),
    ("Alonso Martínez", "Tribunal", "Calle de San Mateo"),
    ("Alonso Martínez", "Chamberí", "Calle de Zurbano"),
    ("Gregorio Marañón", "Nuevos Ministerios", "Paseo de la Castellana"),
    ("Gregorio Marañón", "Chamberí", "Calle de José Abascal"),
    ("Nuevos Ministerios", "Plaza de Castilla", "Paseo de la Castellana"),
    ("Nuevos Ministerios", "Chamberí", "Calle de Santa Engracia"),
    ("Bilbao", "Tribunal", "Calle de Fuencarral"),
    ("Bilbao", "Malasaña", "Calle de Carranza"),
    ("Bilbao", "Chamberí", "Calle de Luchana"),
    ("Tribunal", "Malasaña", "Calle del Pez"),
    ("Malasaña", "San Bernardo", "Calle de San Bernardo"),
    ("San Bernardo", "Plaza de España", "Calle de San Bernardo"),
    ("San Bernardo", "Argüelles", "Calle de Alberto Aguilera"),
    ("Argüelles", "Plaza de España", "Calle de la Princesa"),
    ("Argüelles", "Moncloa", "Calle de la Princesa"),
    ("Moncloa", "Príncipe Pío", "Paseo de la Florida"),
    ("Príncipe Pío", "Plaza de Oriente", "Cuesta de San Vicente"),
    ("Plaza de España", "Plaza de Oriente", "Calle de Bailén"),
]

VELOCIDAD_KMH = {"Moto": 25, "Bici": 15, "Bici eléctrica": 20, "Patinete": 18}
FACTOR_CALLE = 1.25  # la calle real es más larga que la línea recta


def _haversine(a, b):
    la1, lo1, la2, lo2 = map(radians, (*a, *b))
    h = sin((la2 - la1) / 2) ** 2 + cos(la1) * cos(la2) * sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371000 * asin(sqrt(h))


def cargar_grafo():
    """Devuelve (grafo, calles). grafo = {nodo: {vecino: metros}}; calles = {frozenset({a, b}): nombre}."""
    grafo = {n: {} for n in NODOS}
    calles = {}
    for a, b, calle in CALLES:
        metros = round(_haversine(NODOS[a], NODOS[b]) * FACTOR_CALLE)
        grafo[a][b] = metros
        grafo[b][a] = metros
        calles[frozenset((a, b))] = calle
    return grafo, calles


def dijkstra(grafo, origen):
    dist = {n: float("inf") for n in grafo}
    prev = {n: None for n in grafo}
    dist[origen] = 0
    cola = [(0, origen)]
    while cola:
        d, u = heapq.heappop(cola)
        if d > dist[u]:
            continue
        for v, peso in grafo[u].items():
            nd = d + peso
            if nd < dist[v]:
                dist[v], prev[v] = nd, u
                heapq.heappush(cola, (nd, v))
    return dist, prev


def camino(prev, origen, destino):
    ruta, n = [], destino
    while n is not None:
        ruta.append(n)
        n = prev[n]
    ruta.reverse()
    return ruta if ruta and ruta[0] == origen else None


def ruta_mas_corta(grafo, origen, destino):
    dist, prev = dijkstra(grafo, origen)
    return camino(prev, origen, destino), dist[destino]


def rider_mas_cercano(grafo, destino, posiciones):
    dist, prev = dijkstra(grafo, destino)  # grafo no dirigido: la distancia es simétrica
    mejor = min(posiciones, key=lambda rid: dist[posiciones[rid]])
    ruta = camino(prev, destino, posiciones[mejor])[::-1]
    return mejor, dist[posiciones[mejor]], ruta


def posiciones_iniciales(rider_ids, semilla=7):
    rng = random.Random(semilla)
    return {rid: rng.choice(list(NODOS)) for rid in rider_ids}


def describir_ruta(ruta, grafo, calles):
    pasos = []
    for a, b in zip(ruta, ruta[1:]):
        pasos.append(f"{a} -> {b}  por {calles[frozenset((a, b))]} ({grafo[a][b]} m)")
    return pasos


def minutos(metros, vehiculo):
    return max(1, round(metros / 1000 / VELOCIDAD_KMH.get(vehiculo, 15) * 60))

def medir(funcion, *args):
    t0 = perf_counter()
    res = funcion(*args)
    return res, (perf_counter() - t0) * 1000


def bellman_ford(grafo, origen):
    dist = {n: float("inf") for n in grafo}
    prev = {n: None for n in grafo}
    dist[origen] = 0
    aristas = [(u, v, w) for u in grafo for v, w in grafo[u].items()]  #cada calle en los 2 sentidos
    vueltas = relajaciones = 0
    for _ in range(len(grafo) - 1):
        vueltas += 1
        hubo_cambio = False
        for u, v, w in aristas:
            if dist[u] != float("inf") and dist[u] + w < dist[v]:
                dist[v], prev[v] = dist[u] + w, u
                relajaciones += 1
                hubo_cambio = True
        if not hubo_cambio:  #si una vuelta entera no mejora nada, ya hemos terminado
            break
    # una vuelta V-ésima que aún mejore algo => hay un ciclo de peso negativo
    ciclo_negativo = any(dist[u] != float("inf") and dist[u] + w < dist[v] for u, v, w in aristas)
    return dist, prev, {"vueltas": vueltas, "relajaciones": relajaciones, "ciclo_negativo": ciclo_negativo}


def floyd_warshall(grafo):
    nodos = list(grafo)
    inf = float("inf")
    dist = {a: {b: inf for b in nodos} for a in nodos}
    sig = {a: {b: None for b in nodos} for a in nodos}
    for a in nodos:
        dist[a][a], sig[a][a] = 0, a
        for b, peso in grafo[a].items():
            dist[a][b], sig[a][b] = peso, b
    for k in nodos:                      
        dk = dist[k]
        for i in nodos:
            dik = dist[i][k]
            if dik == inf:
                continue
            di, si = dist[i], sig[i]
            for j in nodos:
                nd = dik + dk[j]
                if nd < di[j]:
                    di[j], si[j] = nd, si[k]
    return dist, sig


def camino_floyd(sig, origen, destino):
    if sig[origen][destino] is None:
        return None
    ruta = [origen]
    while origen != destino:
        origen = sig[origen][destino]
        ruta.append(origen)
    return ruta

def sedes_ordenadas(dist, cliente, sedes):
    return sorted(((nombre, nodo, dist[cliente][nodo]) for nombre, nodo in sedes.items()),
                  key=lambda t: (t[2], t[0]))

def evaluar_puntos_espera(grafo, pesos, matriz=None):
    activos = {n: w for n, w in pesos.items() if w > 0}
    total = sum(activos.values())
    filas = []
    for c in grafo:
        d = matriz[c] if matriz is not None else dijkstra(grafo, c)[0]
        filas.append({"nodo": c,
                      "maximo": max(d[n] for n in activos),
                      "media": round(sum(w * d[n] for n, w in activos.items()) / total)})
    return filas
