"""db.py - Conexión, init_db y consultas (CRUD, informes) de RiderExpress."""
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path(__file__).with_name("riderexpress.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS usuario (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    barrio TEXT NOT NULL,
    saldo  REAL NOT NULL DEFAULT 0 CHECK (saldo >= 0)
);
CREATE TABLE IF NOT EXISTS rider (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre   TEXT NOT NULL,
    vehiculo TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plato (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre      TEXT NOT NULL,
    restaurante TEXT NOT NULL,
    categoria   TEXT NOT NULL,
    precio      REAL NOT NULL CHECK (precio > 0),
    UNIQUE (restaurante, nombre)
);
CREATE TABLE IF NOT EXISTS pedido (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha      TEXT NOT NULL,
    usuario_id INTEGER NOT NULL REFERENCES usuario(id),
    rider_id   INTEGER NOT NULL REFERENCES rider(id)
);
CREATE TABLE IF NOT EXISTS pedido_plato (
    pedido_id INTEGER NOT NULL REFERENCES pedido(id) ON DELETE CASCADE,
    plato_id  INTEGER NOT NULL REFERENCES plato(id),
    cantidad  INTEGER NOT NULL CHECK (cantidad > 0),
    PRIMARY KEY (pedido_id, plato_id)
);
CREATE TABLE IF NOT EXISTS reparto (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    zona   TEXT NOT NULL,
    inicio TEXT NOT NULL,
    fin    TEXT NOT NULL,
    CHECK (fin > inicio)
);
CREATE INDEX IF NOT EXISTS idx_plato_restaurante ON plato(restaurante);
CREATE INDEX IF NOT EXISTS idx_pedido_usuario ON pedido(usuario_id);
"""

# ---------------------------------------------------------------- datos de ejemplo
# (nombre, categoría, precio base) por tipo de cocina
CATALOGO = {
    "Madrileña": [
        ("Cocido madrileño", "Principal", 14.5), ("Bocadillo de calamares", "Principal", 7.5),
        ("Callos a la madrileña", "Principal", 12.0), ("Tortilla de patatas", "Entrante", 8.0),
        ("Croquetas de jamón", "Entrante", 9.0), ("Huevos rotos con jamón", "Principal", 11.5),
        ("Patatas bravas", "Entrante", 6.5), ("Soldaditos de Pavía", "Entrante", 8.5),
        ("Torrijas", "Postre", 5.5), ("Churros con chocolate", "Postre", 5.0)],
    "Italiana": [
        ("Pizza margarita", "Principal", 9.5), ("Pizza cuatro quesos", "Principal", 11.0),
        ("Spaghetti carbonara", "Principal", 11.5), ("Lasaña boloñesa", "Principal", 12.0),
        ("Risotto de setas", "Principal", 13.0), ("Gnocchi al pesto", "Principal", 11.5),
        ("Ensalada caprese", "Entrante", 8.5), ("Bruschetta", "Entrante", 6.5),
        ("Tiramisú", "Postre", 5.5), ("Panna cotta", "Postre", 5.0)],
    "Japonesa": [
        ("Sushi variado (12 piezas)", "Principal", 16.0), ("Nigiri de salmón (4 uds)", "Principal", 7.5),
        ("Maki de atún", "Principal", 8.0), ("Ramen tonkotsu", "Principal", 12.5),
        ("Gyozas", "Entrante", 6.5), ("Edamame", "Entrante", 4.5),
        ("Tempura de langostinos", "Entrante", 9.5), ("Yakitori de pollo", "Entrante", 8.5),
        ("Udon de ternera", "Principal", 12.0), ("Mochi de té verde", "Postre", 5.0)],
    "Mexicana": [
        ("Tacos al pastor", "Principal", 9.0), ("Burrito de pollo", "Principal", 10.0),
        ("Quesadilla de queso", "Principal", 8.0), ("Nachos con guacamole", "Entrante", 8.5),
        ("Enchiladas verdes", "Principal", 11.5), ("Fajitas de ternera", "Principal", 13.5),
        ("Guacamole", "Entrante", 7.0), ("Chilaquiles", "Principal", 9.5),
        ("Tres leches", "Postre", 5.5), ("Horchata", "Bebida", 3.5)],
    "India": [
        ("Pollo tikka masala", "Principal", 12.5), ("Cordero rogan josh", "Principal", 14.0),
        ("Biryani de pollo", "Principal", 12.0), ("Palak paneer", "Principal", 11.0),
        ("Dal tadka", "Principal", 9.5), ("Samosas", "Entrante", 5.5),
        ("Pan naan", "Entrante", 3.0), ("Pakoras de verdura", "Entrante", 6.0),
        ("Lassi de mango", "Bebida", 4.0), ("Gulab jamun", "Postre", 5.0)],
    "Hamburguesas": [
        ("Hamburguesa clásica", "Principal", 10.5), ("Cheeseburger doble", "Principal", 12.5),
        ("Burger BBQ con bacon", "Principal", 13.0), ("Burger de pollo crujiente", "Principal", 11.0),
        ("Burger vegetal", "Principal", 11.5), ("Patatas fritas", "Entrante", 4.5),
        ("Aros de cebolla", "Entrante", 5.5), ("Alitas de pollo", "Entrante", 8.0),
        ("Batido de vainilla", "Bebida", 4.5), ("Brownie con helado", "Postre", 5.5)],
    "Vegetariana": [
        ("Bowl de quinoa y aguacate", "Principal", 11.0), ("Hummus con crudités", "Entrante", 7.0),
        ("Wrap de falafel", "Principal", 9.5), ("Curry de garbanzos", "Principal", 10.5),
        ("Ensalada de lentejas", "Entrante", 9.0), ("Hamburguesa de remolacha", "Principal", 11.0),
        ("Crema de calabaza", "Entrante", 7.5), ("Pad thai vegetal", "Principal", 10.5),
        ("Tarta de zanahoria", "Postre", 5.5), ("Smoothie verde", "Bebida", 5.0)],
    "China": [
        ("Arroz tres delicias", "Principal", 7.5), ("Pollo con almendras", "Principal", 10.0),
        ("Cerdo agridulce", "Principal", 10.5), ("Chow mein de ternera", "Principal", 10.0),
        ("Rollitos de primavera", "Entrante", 5.5), ("Dumplings al vapor", "Entrante", 7.0),
        ("Sopa agripicante", "Entrante", 6.0), ("Pato laqueado", "Principal", 16.0),
        ("Fideos de arroz con gambas", "Principal", 11.0), ("Plátano frito con miel", "Postre", 4.5)],
    "Árabe": [
        ("Shawarma de pollo", "Principal", 8.5), ("Kebab de cordero", "Principal", 10.0),
        ("Falafel con hummus", "Entrante", 8.0), ("Tabulé", "Entrante", 7.0),
        ("Baba ganoush", "Entrante", 7.0), ("Kafta con arroz", "Principal", 11.5),
        ("Cuscús de verduras", "Principal", 10.5), ("Tajín de pollo con limón", "Principal", 12.5),
        ("Baklava", "Postre", 5.0), ("Té moruno", "Bebida", 3.0)],
    "Peruana": [
        ("Ceviche clásico", "Principal", 13.5), ("Lomo saltado", "Principal", 14.0),
        ("Ají de gallina", "Principal", 12.5), ("Tiradito de atún", "Entrante", 14.0),
        ("Causa limeña", "Entrante", 9.0), ("Anticuchos de ternera", "Entrante", 9.5),
        ("Arroz chaufa", "Principal", 11.0), ("Papa a la huancaína", "Entrante", 7.5),
        ("Suspiro limeño", "Postre", 5.5), ("Chicha morada", "Bebida", 3.5)],
}

# (restaurante, cocina, nodo del grafo donde está) -> 50 restaurantes, 5 por cocina
RESTAURANTES = [
    ("La Taberna del Oso", "Madrileña", "Sol"), ("Casa Chamberí", "Madrileña", "Chamberí"),
    ("El Rincón de Embajadores", "Madrileña", "Embajadores"), ("Mesón La Latina", "Madrileña", "La Latina"),
    ("Bodega Plaza Mayor", "Madrileña", "Plaza Mayor"),
    ("Trattoria Il Retiro", "Italiana", "Ibiza"), ("Pizzería Napoli Chueca", "Italiana", "Chueca"),
    ("La Piccola Roma", "Italiana", "Tribunal"), ("Osteria Gran Vía", "Italiana", "Callao"),
    ("Bella Atocha", "Italiana", "Atocha"),
    ("Sakura Malasaña", "Japonesa", "Malasaña"), ("Izakaya Cibeles", "Japonesa", "Cibeles"),
    ("Ramen Moncloa", "Japonesa", "Moncloa"), ("Tokio Goya", "Japonesa", "Goya"),
    ("Sushi Colón", "Japonesa", "Colón"),
    ("Taquería El Güero", "Mexicana", "Lavapiés"), ("Cantina Doña Lupe", "Mexicana", "Antón Martín"),
    ("Mezcal y Maíz", "Mexicana", "Bilbao"), ("Casa Azteca", "Mexicana", "Argüelles"),
    ("Tacos Velázquez", "Mexicana", "Velázquez"),
    ("Taj Madrid", "India", "Tirso de Molina"), ("Bombay Express", "India", "Nuevos Ministerios"),
    ("Curry Corner", "India", "Alonso Martínez"), ("Delhi Palace", "India", "Manuel Becerra"),
    ("Masala Real", "India", "Santo Domingo"),
    ("Burger Sol", "Hamburguesas", "Sol"), ("Grill 28", "Hamburguesas", "San Bernardo"),
    ("The Patty House", "Hamburguesas", "Malasaña"), ("Burger Castilla", "Hamburguesas", "Plaza de Castilla"),
    ("Smash Legazpi", "Hamburguesas", "Legazpi"),
    ("Verde Que Te Quiero", "Vegetariana", "Chueca"), ("Raíces", "Vegetariana", "Segovia"),
    ("Brote", "Vegetariana", "Gregorio Marañón"), ("Hortus", "Vegetariana", "Sevilla"),
    ("Green Bowl", "Vegetariana", "Banco de España"),
    ("Dragón de Oro", "China", "Puerta de Toledo"), ("Gran Muralla", "China", "Plaza de España"),
    ("Jade Pekín", "China", "Ópera"), ("Wok Express", "China", "Red de San Luis"),
    ("Shanghai Garden", "China", "Príncipe Pío"),
    ("Al-Andalus", "Árabe", "Plaza de Oriente"), ("Damasco", "Árabe", "Embajadores"),
    ("Zaytún", "Árabe", "Puerta de Alcalá"), ("Oasis", "Árabe", "Tirso de Molina"),
    ("Beirut Kebab", "Árabe", "Atocha"),
    ("Lima 41", "Peruana", "Argüelles"), ("Machu Picchu", "Peruana", "Callao"),
    ("Pisco y Sabor", "Peruana", "Chamberí"), ("Nikkei Norte", "Peruana", "Plaza de Castilla"),
    ("La Huaca", "Peruana", "Velázquez"),
]
COCINA_DE = {n: c for n, c, _ in RESTAURANTES}
NODO_DE = {n: nodo for n, _, nodo in RESTAURANTES}
COCINAS = sorted(CATALOGO)

USUARIOS = [
    ("Lucía Fernández", "Malasaña", 85.0), ("Carlos Ruiz", "Chamberí", 60.0),
    ("Marta Gómez", "Lavapiés", 45.5), ("Javier Sánchez", "Argüelles", 120.0),
    ("Elena Torres", "Atocha", 30.0), ("Pablo Díaz", "Chueca", 75.0),
    ("Sara Moreno", "La Latina", 95.0), ("Álvaro Jiménez", "Goya", 55.0),
    ("Laura Navarro", "Moncloa", 40.0), ("Daniel Romero", "Nuevos Ministerios", 110.0),
    ("Paula Castillo", "Tirso de Molina", 25.0), ("Sergio Ortega", "Legazpi", 70.0),
    ("Irene Molina", "Velázquez", 65.0), ("Adrián Vega", "Bilbao", 50.0),
    ("Claudia Serrano", "Sol", 90.0),
]
RIDERS = [
    ("Miguel Herrera", "Moto"), ("Ana Cabrera", "Bici"), ("Rubén Prieto", "Bici eléctrica"),
    ("Nuria Campos", "Moto"), ("Hugo Santos", "Patinete"), ("Alba Reyes", "Bici"),
    ("Iván Gallego", "Moto"), ("Carmen Ibáñez", "Bici eléctrica"), ("Óscar Pastor", "Bici"),
    ("Silvia Rubio", "Moto"),
]
ZONAS_REPARTO = ["Sol", "Chueca", "Malasaña", "Lavapiés", "Atocha", "Chamberí",
                 "Argüelles", "Goya", "La Latina", "Colón", "Moncloa", "Cibeles"]


# ---------------------------------------------------------------- conexión e init
def conectar():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(reset=False):
    if reset and DB_PATH.exists():
        DB_PATH.unlink()
    conn = conectar()
    try:
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM plato").fetchone()[0] == 0:
            _poblar(conn)
            conn.commit()
    finally:
        conn.close()


def _hhmm(minutos):
    return f"{minutos // 60:02d}:{minutos % 60:02d}"


def _poblar(conn):
    rng = random.Random(2026)
    conn.executemany("INSERT INTO usuario (nombre, barrio, saldo) VALUES (?, ?, ?)", USUARIOS)
    conn.executemany("INSERT INTO rider (nombre, vehiculo) VALUES (?, ?)", RIDERS)
    for restaurante, cocina, _ in RESTAURANTES:
        for nombre, cat, precio in rng.sample(CATALOGO[cocina], rng.randint(8, 10)):
            p = max(2.5, round(precio * rng.uniform(0.92, 1.12) * 2) / 2)
            conn.execute("INSERT INTO plato (nombre, restaurante, categoria, precio) VALUES (?, ?, ?, ?)",
                         (nombre, restaurante, cat, p))
    # Histórico de pedidos para que los informes tengan datos
    base = datetime(2026, 10, 1, 12, 0)
    for _ in range(80):
        restaurante = rng.choice(RESTAURANTES)[0]
        platos = conn.execute("SELECT id FROM plato WHERE restaurante = ?", (restaurante,)).fetchall()
        fecha = (base + timedelta(days=rng.randint(0, 27), minutes=rng.randint(0, 600))).isoformat(timespec="seconds")
        cur = conn.execute("INSERT INTO pedido (fecha, usuario_id, rider_id) VALUES (?, ?, ?)",
                           (fecha, rng.randint(1, len(USUARIOS)), rng.randint(1, len(RIDERS))))
        for p in rng.sample(platos, rng.randint(1, 4)):
            conn.execute("INSERT INTO pedido_plato VALUES (?, ?, ?)", (cur.lastrowid, p["id"], rng.randint(1, 3)))
    # Repartos del turno (se solapan entre sí: el voraz elige un subconjunto compatible)
    for _ in range(30):
        ini = rng.randrange(8 * 60, 21 * 60, 5)
        fin = min(ini + rng.randrange(20, 95, 5), 23 * 60 + 55)
        conn.execute("INSERT INTO reparto (zona, inicio, fin) VALUES (?, ?, ?)",
                     (rng.choice(ZONAS_REPARTO), _hhmm(ini), _hhmm(fin)))


# ---------------------------------------------------------------- helpers
def _todos(sql, params=()):
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


def _uno(sql, params=()):
    filas = _todos(sql, params)
    return filas[0] if filas else None


def _escribir(sql, params=()):
    conn = conectar()
    try:
        with conn:
            return conn.execute(sql, params).lastrowid
    finally:
        conn.close()


# ---------------------------------------------------------------- CRUD usuario
def crear_usuario(nombre, barrio, saldo=0.0):
    return _escribir("INSERT INTO usuario (nombre, barrio, saldo) VALUES (?, ?, ?)", (nombre, barrio, saldo))


def listar_usuarios():
    return _todos("SELECT * FROM usuario ORDER BY id")


def obtener_usuario(usuario_id):
    return _uno("SELECT * FROM usuario WHERE id = ?", (usuario_id,))


def recargar_saldo(usuario_id, importe):
    _escribir("UPDATE usuario SET saldo = saldo + ? WHERE id = ?", (importe, usuario_id))


def borrar_usuario(usuario_id):
    """Falla con IntegrityError si el usuario ya tiene pedidos."""
    _escribir("DELETE FROM usuario WHERE id = ?", (usuario_id,))


# ---------------------------------------------------------------- CRUD plato / restaurantes
def crear_plato(nombre, restaurante, categoria, precio):
    return _escribir("INSERT INTO plato (nombre, restaurante, categoria, precio) VALUES (?, ?, ?, ?)",
                     (nombre, restaurante, categoria, precio))


def actualizar_precio(plato_id, precio):
    _escribir("UPDATE plato SET precio = ? WHERE id = ?", (precio, plato_id))


def borrar_plato(plato_id):
    _escribir("DELETE FROM plato WHERE id = ?", (plato_id,))


def platos_de_restaurante(restaurante):
    return _todos("SELECT * FROM plato WHERE restaurante = ? ORDER BY id", (restaurante,))


def listar_restaurantes(cocina=None):
    filas = _todos("SELECT restaurante, COUNT(*) AS platos FROM plato GROUP BY restaurante ORDER BY restaurante")
    for f in filas:
        f["cocina"] = COCINA_DE.get(f["restaurante"], "?")
        f["nodo"] = NODO_DE.get(f["restaurante"])
    return [f for f in filas if cocina is None or f["cocina"] == cocina]


# ---------------------------------------------------------------- riders, pedidos y repartos
def listar_riders():
    return _todos("SELECT * FROM rider ORDER BY id")


def contar_pedidos():
    return _uno("SELECT COUNT(*) AS n FROM pedido")["n"]


def detalle_pedido(pedido_id):
    return _todos("""SELECT pl.nombre, pp.cantidad, pl.precio, pp.cantidad * pl.precio AS subtotal
                     FROM pedido_plato pp JOIN plato pl ON pl.id = pp.plato_id
                     WHERE pp.pedido_id = ?""", (pedido_id,))


def listar_repartos():
    return _todos("SELECT * FROM reparto ORDER BY inicio, fin")


# ---------------------------------------------------------------- informes
def ventas_por_restaurante(limite=10):
    return _todos("""SELECT pl.restaurante, COUNT(DISTINCT pe.id) AS pedidos,
                            ROUND(SUM(pp.cantidad * pl.precio), 2) AS ingresos
                     FROM pedido pe JOIN pedido_plato pp ON pp.pedido_id = pe.id
                                    JOIN plato pl ON pl.id = pp.plato_id
                     GROUP BY pl.restaurante ORDER BY ingresos DESC LIMIT ?""", (limite,))


def platos_mas_vendidos(limite=10):
    return _todos("""SELECT pl.nombre, pl.restaurante, SUM(pp.cantidad) AS unidades
                     FROM pedido_plato pp JOIN plato pl ON pl.id = pp.plato_id
                     GROUP BY pl.id ORDER BY unidades DESC, pl.nombre LIMIT ?""", (limite,))


def gasto_por_usuario():
    return _todos("""SELECT u.nombre, u.barrio, COUNT(DISTINCT pe.id) AS pedidos,
                            ROUND(COALESCE(SUM(pp.cantidad * pl.precio), 0), 2) AS gastado
                     FROM usuario u LEFT JOIN pedido pe ON pe.usuario_id = u.id
                                    LEFT JOIN pedido_plato pp ON pp.pedido_id = pe.id
                                    LEFT JOIN plato pl ON pl.id = pp.plato_id
                     GROUP BY u.id ORDER BY gastado DESC""")


def pedidos_por_rider():
    return _todos("""SELECT r.nombre, r.vehiculo, COUNT(pe.id) AS pedidos
                     FROM rider r LEFT JOIN pedido pe ON pe.rider_id = r.id
                     GROUP BY r.id ORDER BY pedidos DESC""")


# ---------------------------------------------------------------- ampliación: rutas con pedidos reales
def pedidos_con_destino(limite=15):
    """Últimos pedidos con lo necesario para trazar su ruta: restaurante (origen), barrio del cliente (destino)
    y rider/vehículo. Un pedido es siempre de un solo restaurante, por eso MIN() es seguro."""
    return _todos("""SELECT pe.id, pe.fecha, MIN(pl.restaurante) AS restaurante,
                            u.nombre AS cliente, u.barrio, r.nombre AS rider, r.vehiculo
                     FROM pedido pe JOIN usuario u ON u.id = pe.usuario_id
                                    JOIN rider r ON r.id = pe.rider_id
                                    JOIN pedido_plato pp ON pp.pedido_id = pe.id
                                    JOIN plato pl ON pl.id = pp.plato_id
                     GROUP BY pe.id ORDER BY pe.id DESC LIMIT ?""", (limite,))
